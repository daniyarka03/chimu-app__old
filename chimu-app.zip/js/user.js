const button_invite = document.querySelector('.section-basic__button');
const button__close = document.querySelector('.modal__close');

// button_invite.addEventListener('click', () => {
//     $('body').css("overflow", "hidden");
// });

// button__close.addEventListener('click', () => {
//     alert('hello')
// });



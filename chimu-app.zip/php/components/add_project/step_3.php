<section class="section-add-project register__step_3">
    <div class="container">
        <div class="section-header">
            <h2 class="section-add-project__title">Создание проекта</h2>
        </div>
        <div class="section-forms">
            <input type="file" name="file" class="section-add-project__input" placeholder="Загрузить изображение"/>
        </div>
        <div class="section-controls">
            <button type="submit" name="submit" class="section-add-project__button_next next_2">Завершить</button>
            <button type="button" class="section-add-project__button_back back_2">Назад</button>
        </div>
    </div>
</section>
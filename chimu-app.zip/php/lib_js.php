<link rel="stylesheet" href="css/multiselect_plugin/chosen.min.css">
<script src="js/jquery.js"></script>
<script src="js/multiselect_plugin/chosen.jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $('#category_object').chosen();
        $('#mselectCountry').chosen();
        $('#mselectCity').chosen();
        $('#mselectWork').chosen();
    });
</script>
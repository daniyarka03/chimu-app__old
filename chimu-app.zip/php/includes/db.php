<?php
    require "rb.php";
    R::setup('mysql:host=localhost;dbname=chimu-team', 'root', '' );
?>